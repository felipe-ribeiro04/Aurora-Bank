package model.persistencia;

public class Cliente extends Usuario {

    private int id_cliente;
    private float score_credito;

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public float getScore_credito() {
        return score_credito;
    }

    public void setScore_credito(float score_credito) {
        this.score_credito = score_credito;
    }

    @Override
    public String toString() {
        return "Nome: " + getNome() + "\nCPF: " + getCpf();
    }
}