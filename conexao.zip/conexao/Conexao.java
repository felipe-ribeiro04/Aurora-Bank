package model; 

import java.sql.Connection; 
import java.sql.SQLException; 
import java.sql.DriverManager;

public class Conexao{

//Atributos com os dados de autenticação: 
String usuario = "root"; 
String senha = "Joao1234";
String url = "jdbc:mysql://localhost:3306/aurora_pay"; 
String driver = "com.mysql.cj.jdbc.Driver";

Connection conexao = null; 

//Método que estabelece a conexão: |
public Connection conectar() throws ClassNotFoundException{
try{
//Tentativa de conexão com o banco de dados: 
if(conexao == null){
Class.forName(driver); 
conexao = (Connection)DriverManager.getConnection(url, usuario, senha);
System.out.println(); 
}
}catch(SQLException e){
//Apresentar o erro:
System. out.println("Erro conexão!"); 
e.printStackTrace();
e.getMessage(); 
}

return conexao;

    }
}


