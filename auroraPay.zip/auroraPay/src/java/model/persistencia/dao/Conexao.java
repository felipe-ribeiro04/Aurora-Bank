
package model.persistencia.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    static String usuario = "root";
    static String senha = "teste";
    static String url = "jdbc:mysql://localhost:3306/aurora_pay";
    static String driver = "com.mysql.cj.jdbc.Driver";
    
    static Connection conexao = null;
    
    //metodo que irá ativar a conexao    
    public static Connection conectar() { //throws ClassNotFoundException{
        try{
            if(conexao == null){
                Class.forName(driver);
                conexao = (Connection)DriverManager.getConnection(url,usuario, senha);
                System.out.println(conexao.getClass().getName());
                System.out.println("Conexao com o banco aurora_pay ativa"); 
            }
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Conexao falhou");
            System.out.println(e);
        }
        return conexao;
    }
    //criar um metodo para destruir a conexao quando sair do sistema
}
