package model.persistencia.dao;
import java.security.Timestamp;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.persistencia.Cliente;
import model.persistencia.Endereco;

public class ContaDao {
    private Connection conn;

    public ContaDao() {
        try {
            if (this.conn == null || this.conn.isClosed()) {
                this.conn = Conexao.conectar();
            }
        } catch (Exception e) {
            System.out.println("Erro ao inicializar conexão no DAO");
            e.printStackTrace();
        }
    }
    
    public Conta depositar(){
        
    }
}
