package model.persistencia.dao;

import java.security.Timestamp;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.persistencia.Cliente;
import model.persistencia.Endereco;

public class ClienteDao {

    private Connection conn;

    public ClienteDao() {
        try {
            if (this.conn == null || this.conn.isClosed()) {
                this.conn = Conexao.conectar();
            }
        } catch (Exception e) {
            System.out.println("Erro ao inicializar conexão no DAO");
            e.printStackTrace();
        }

    }

    public Cliente cadastrar(Cliente cliente) {
        PreparedStatement stmtUsuario = null;
        PreparedStatement stmtEndereco = null;
        PreparedStatement stmtCliente = null;
        ResultSet rs = null;

        try {
            // Insere o usuario no banco
            String sqlUsuario = "INSERT INTO usuario (nome, cpf, telefone, tipo_usuario, senha_hash, otp_ativo, data_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmtUsuario = conn.prepareStatement(sqlUsuario, Statement.RETURN_GENERATED_KEYS);
            stmtUsuario.setString(1, cliente.getNome());
            stmtUsuario.setString(2, cliente.getCpf());
            stmtUsuario.setString(3, cliente.getTelefone());
            stmtUsuario.setString(4, "CLIENTE");
            stmtUsuario.setString(5, cliente.getSenha_hash());
            stmtUsuario.setString(6, cliente.getOtp_ativo());

            // Converter data_nascimento para java.sql.Date
            java.sql.Date dataNascimento = null;
            if (cliente.getData_nascimento() instanceof java.sql.Date) {
                dataNascimento = (java.sql.Date) cliente.getData_nascimento();
            } else {
                dataNascimento = new java.sql.Date(cliente.getData_nascimento().getTime());
            }
            stmtUsuario.setDate(7, dataNascimento);

            stmtUsuario.executeUpdate();

            rs = stmtUsuario.getGeneratedKeys();
            int idUsuario = 0;
            if (rs.next()) {
                idUsuario = rs.getInt(1);
            }
            rs.close();
            stmtUsuario.close();

            if (idUsuario == 0) {
                throw new SQLException("Erro ao obter id_usuario após insert.");
            }

            // Inserir endereco com id_usuario obtido
            String sqlEndereco = "INSERT INTO endereco (id_usuario, cep, local, numero_casa, bairro, cidade, estado, complemento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmtEndereco = conn.prepareStatement(sqlEndereco, Statement.RETURN_GENERATED_KEYS);
            stmtEndereco.setInt(1, idUsuario);
            stmtEndereco.setString(2, cliente.getEndereco().getCep());
            stmtEndereco.setString(3, cliente.getEndereco().getLocal());
            stmtEndereco.setInt(4, cliente.getEndereco().getNumero_casa());
            stmtEndereco.setString(5, cliente.getEndereco().getBairro());
            stmtEndereco.setString(6, cliente.getEndereco().getCidade());
            stmtEndereco.setString(7, cliente.getEndereco().getEstado());
            stmtEndereco.setString(8, cliente.getEndereco().getComplemento());
            stmtEndereco.executeUpdate();

            rs = stmtEndereco.getGeneratedKeys();
            int idEndereco = 0;
            if (rs.next()) {
                idEndereco = rs.getInt(1);
            }
            rs.close();
            stmtEndereco.close();

            if (idEndereco == 0) {
                throw new SQLException("Erro ao obter id_endereco após insert.");
            }

            // Inserir cliente com id_usuario
            String sqlCliente = "INSERT INTO cliente (id_usuario, score_credito) VALUES (?, ?)";
            stmtCliente = conn.prepareStatement(sqlCliente, Statement.RETURN_GENERATED_KEYS);
            stmtCliente.setInt(1, idUsuario);
            stmtCliente.setFloat(2, cliente.getScore_credito());
            stmtCliente.executeUpdate();

            rs = stmtCliente.getGeneratedKeys();
            int idCliente = 0;
            if (rs.next()) {
                idCliente = rs.getInt(1);
            }
            rs.close();
            stmtCliente.close();

            // Atualiza IDs no objeto cliente
            cliente.setId_usuario(idUsuario);
            cliente.setId_cliente(idCliente);

            return cliente;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Cliente> buscarTodos() throws SQLException {
        PreparedStatement stmt = null;

        try {
            String sqlCliente = """
                    SELECT 
                        c.id_cliente,
                        u.nome,
                        u.cpf,
                        u.telefone,
                        e.cep,
                        e.local,
                        e.numero_casa,
                        e.bairro,
                        e.cidade,
                        e.estado
                    FROM cliente as c
                    JOIN usuario as u ON c.id_usuario = u.id_usuario
                    JOIN endereco as e ON u.id_usuario = e.id_usuario;
                """;
            stmt = conn.prepareStatement(sqlCliente);
            ResultSet rs = stmt.executeQuery();

            List<Cliente> todos = new ArrayList<>();

            while (rs.next()) {
                Cliente cliente = new Cliente();
                int clienteId = rs.getInt("id_cliente");
                cliente.setId_cliente(clienteId);
                String nome = rs.getString("nome");
                cliente.setNome(nome);
                String cpf = rs.getString("cpf");
                cliente.setCpf(cpf);
                String telefone = rs.getString("telefone");
                cliente.setTelefone(telefone);

                // a cada loop adiciona o cliente na lista 
                todos.add(cliente);
            }
            return todos;
        } catch (SQLException e) {
            e.printStackTrace();
            e.getMessage();
            return null;
        }

    }

    public List<Cliente> buscarPorNome(String nome) {

        PreparedStatement stmt = null;

        try {
            String sqlCliente = """
                    SELECT
                        c.id_cliente,
                        u.nome,
                        u.cpf,
                        u.telefone,
                        e.cep,
                        e.local,
                        e.numero_casa,
                        e.bairro,
                        e.cidade,
                        e.estado 
                    FROM cliente as c
                    JOIN usuario as u ON c.id_usuario = u.id_usuario
                    JOIN endereco as e ON u.id_usuario = e.id_usuario
                    WHERE (u.nome) LIKE ?;    
                """;

            stmt = conn.prepareStatement(sqlCliente);
            stmt.setString(1, "%" + nome + "%");

            ResultSet rs = stmt.executeQuery();

            List<Cliente> todos = new ArrayList<>();

            while (rs.next()) {
                Cliente cliente = new Cliente();
                int clienteId = rs.getInt("id_cliente");
                cliente.setId_cliente(clienteId);
                String nomeCliente = rs.getString("nome");
                cliente.setNome(nomeCliente);
                String cpf = rs.getString("cpf");
                cliente.setCpf(cpf);
                String telefone = rs.getString("telefone");
                cliente.setTelefone(telefone);

                // a cada loop adiciona o cliente na lista 
                todos.add(cliente);
            }
            return todos;
        } catch (SQLException e) {
            e.printStackTrace();
            e.getMessage();
            return null;
        }
    }

    public Cliente buscarPorId(int id) {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sqlCliente = """
                SELECT 
                    c.id_cliente,
                    u.id_usuario,
                    u.nome,
                    u.cpf,
                    u.telefone,
                    u.data_nascimento,
                    u.senha_hash,
                    u.otp_ativo, 
                    e.id_endereco,
                    e.cep,
                    e.local,
                    e.numero_casa,
                    e.bairro,
                    e.cidade,
                    e.estado,
                    e.complemento
                FROM cliente AS c
                JOIN usuario AS u ON c.id_usuario = u.id_usuario 
                JOIN endereco AS e ON u.id_usuario = e.id_usuario
                WHERE c.id_cliente = ?;                
                """;
            stmt = conn.prepareStatement(sqlCliente);
            stmt.setInt(1, id);

            rs = stmt.executeQuery();

            if (rs.next()) {
                Cliente cliente = new Cliente();
                Endereco end = new Endereco();

                // Cliente
                cliente.setId_cliente(rs.getInt("id_cliente"));
                cliente.setId_usuario(rs.getInt("id_usuario"));
                cliente.setNome(rs.getString("nome"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setData_nascimento(rs.getDate("data_nascimento"));
                cliente.setSenha_hash(rs.getString("senha_hash"));
                cliente.setOtp_ativo(rs.getString("otp_ativo"));

                // Endereço
                end.setId_endereco(rs.getInt("id_endereco"));
                end.setCep(rs.getString("cep"));
                end.setLocal(rs.getString("local"));
                end.setNumero_casa(rs.getInt("numero_casa"));
                end.setBairro(rs.getString("bairro"));
                end.setCidade(rs.getString("cidade"));
                end.setEstado(rs.getString("estado"));
                end.setComplemento(rs.getString("complemento"));

                cliente.setEndereco(end);

                return cliente;
            }

            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
    
    public Cliente buscarPorCpf(String cpf) {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sqlCliente = """
                SELECT 
                    u.id_usuario,
                    c.id_cliente,
                    u.nome,
                    u.cpf,
                    u.senha_hash
                FROM usuario u
                JOIN cliente c ON c.id_usuario = u.id_usuario
                WHERE (u.cpf) = ? AND tipo_usuario = 'CLIENTE';
            """;
            
            stmt = conn.prepareStatement(sqlCliente);
            stmt.setString(1, cpf);

            rs = stmt.executeQuery();

            if (rs.next()) {
                Cliente cliente = new Cliente();

                // Cliente
                cliente.setId_usuario(rs.getInt("id_usuario"));
                cliente.setId_cliente(rs.getInt("id_cliente"));
                cliente.setNome(rs.getString("nome"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setSenha_hash(rs.getString("senha_hash"));

                return cliente;
            } 
            else {
                return null;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public boolean excluir(int id) {
        return false;
    }

    public Cliente alterarStatus(int id) {
        return null;
    }

    public Cliente alterarCliente(Cliente cliente) {
        PreparedStatement stmtEndereco = null;
        PreparedStatement stmtUsuario = null;

        try {
            conn.setAutoCommit(false); // controle transacao

            // Atualiza ENDEREÇO
            String sqlEndereco = "UPDATE endereco SET cep = ?, local = ?, numero_casa = ?, bairro = ?, cidade = ?, estado = ?, complemento = ? WHERE id_endereco = ?";
            stmtEndereco = conn.prepareStatement(sqlEndereco);
            stmtEndereco.setString(1, cliente.getEndereco().getCep());
            stmtEndereco.setString(2, cliente.getEndereco().getLocal());
            stmtEndereco.setInt(3, cliente.getEndereco().getNumero_casa());
            stmtEndereco.setString(4, cliente.getEndereco().getBairro());
            stmtEndereco.setString(5, cliente.getEndereco().getCidade());
            stmtEndereco.setString(6, cliente.getEndereco().getEstado());
            stmtEndereco.setString(7, cliente.getEndereco().getComplemento());
            stmtEndereco.setInt(8, cliente.getEndereco().getId_endereco());
            int linhasEndereco = stmtEndereco.executeUpdate();
            System.out.println(linhasEndereco);
            stmtEndereco.close();

            // Atualiza USUÁRIO
            String sqlUsuario = "UPDATE usuario SET nome = ?, cpf = ?, telefone = ?, senha_hash = ?, otp_ativo = ? WHERE id_usuario = ?";
            stmtUsuario = conn.prepareStatement(sqlUsuario);
            stmtUsuario.setString(1, cliente.getNome());
            stmtUsuario.setString(2, cliente.getCpf());
            stmtUsuario.setString(3, cliente.getTelefone());
            stmtUsuario.setString(4, cliente.getSenha_hash());
            stmtUsuario.setString(5, cliente.getOtp_ativo());
            stmtUsuario.setInt(6, cliente.getId_usuario());
            int linhasUsuario = stmtUsuario.executeUpdate();
            System.out.println(linhasUsuario);
            stmtUsuario.close();

            // Verifica se atualizou
            if (linhasEndereco == 0 || linhasUsuario == 0) {
                conn.rollback();
                return null;
            }

            conn.commit(); // <--- essencial

            return cliente;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
