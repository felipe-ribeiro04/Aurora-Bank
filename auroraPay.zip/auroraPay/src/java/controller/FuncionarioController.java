
package controller;
import model.persistencia.Funcionario;
import model.persistencia.dao.FuncionarioDao;

public class FuncionarioController {
    
    public Funcionario cadastrar(Funcionario funcionario) {
           FuncionarioDao funcionarioDao = new FuncionarioDao();
           funcionario = funcionarioDao.cadastrar(funcionario); 
           return funcionario;
    }
    
    public Funcionario buscarPorCpf(String cpf) {
        FuncionarioDao funcionarioDao = new FuncionarioDao();
        Funcionario funcionario = new Funcionario();
        funcionario = funcionarioDao.buscarPorCpf(cpf);
        return funcionario;
    }
}
