package model.persistencia.dao;

import model.persistencia.Funcionario;
import model.persistencia.Endereco;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Date;
import java.security.Timestamp;
import java.util.ArrayList;
import java.util.List;



public class FuncionarioDao {

    private Connection conn;
    
    public FuncionarioDao() {
        try {
            if (this.conn == null || this.conn.isClosed()) {
                this.conn = Conexao.conectar();
            }
        } catch (Exception e) {
            System.out.println("Erro ao inicializar conexão no DAO");
            e.printStackTrace();
        }

    }

    public Funcionario cadastrar(Funcionario funcionario) {
        PreparedStatement stmtUsuario = null;
        PreparedStatement stmtEndereco = null;
        PreparedStatement stmtFuncionario = null;
        ResultSet rs = null;

        try {
            // 1. Inserir usuario
            String sqlUsuario = "INSERT INTO usuario (nome, cpf, telefone, tipo_usuario, senha_hash, otp_ativo, data_nascimento) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmtUsuario = conn.prepareStatement(sqlUsuario, Statement.RETURN_GENERATED_KEYS);
            stmtUsuario.setString(1, funcionario.getNome());
            stmtUsuario.setString(2, funcionario.getCpf());
            stmtUsuario.setString(3, funcionario.getTelefone());
            stmtUsuario.setString(4, "FUNCIONARIO");
            stmtUsuario.setString(5, funcionario.getSenha_hash());
            stmtUsuario.setString(6, funcionario.getOtp_ativo());

            // Converter data_nascimento para java.sql.Date
            java.sql.Date dataNascimento = null;
            if (funcionario.getData_nascimento() instanceof java.sql.Date) {
                dataNascimento = (java.sql.Date) funcionario.getData_nascimento();
            } else {
                dataNascimento = new java.sql.Date(funcionario.getData_nascimento().getTime());
            }
            stmtUsuario.setDate(7, dataNascimento);

            stmtUsuario.executeUpdate();

            rs = stmtUsuario.getGeneratedKeys();
            int idUsuario = 0;
            if (rs.next()) {
                idUsuario = rs.getInt(1);
            }
            rs.close();
            stmtUsuario.close();

            if (idUsuario == 0) {
                throw new SQLException("Erro ao obter id_usuario após insert.");
            }

            // 2. Inserir endereco com id_usuario obtido
            String sqlEndereco = "INSERT INTO endereco (id_usuario, cep, local, numero_casa, bairro, cidade, estado, complemento) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmtEndereco = conn.prepareStatement(sqlEndereco, Statement.RETURN_GENERATED_KEYS);
            stmtEndereco.setInt(1, idUsuario);
            stmtEndereco.setString(2, funcionario.getEndereco().getCep());
            stmtEndereco.setString(3, funcionario.getEndereco().getLocal());
            stmtEndereco.setInt(4, funcionario.getEndereco().getNumero_casa());
            stmtEndereco.setString(5, funcionario.getEndereco().getBairro());
            stmtEndereco.setString(6, funcionario.getEndereco().getCidade());
            stmtEndereco.setString(7, funcionario.getEndereco().getEstado());
            stmtEndereco.setString(8, funcionario.getEndereco().getComplemento());
            stmtEndereco.executeUpdate();

            rs = stmtEndereco.getGeneratedKeys();
            int idEndereco = 0;
            if (rs.next()) {
                idEndereco = rs.getInt(1);
            }
            rs.close();
            stmtEndereco.close();

            if (idEndereco == 0) {
                throw new SQLException("Erro ao obter id_endereco após insert.");
            }

            // 3. Inserir funcionario com id_usuario
            String sqlFuncionario = "INSERT INTO funcionario (id_usuario, codigo_funcionario, cargo, id_supervisor) VALUES (?, ?, ?, ?)";
            stmtFuncionario = conn.prepareStatement(sqlFuncionario, Statement.RETURN_GENERATED_KEYS);
            stmtFuncionario.setInt(1, idUsuario);
            stmtFuncionario.setString(2, funcionario.getCodigo_funcionario());
            stmtFuncionario.setString(3, funcionario.getCargo());
            stmtFuncionario.setInt(4, 1);
            stmtFuncionario.executeUpdate();

            rs = stmtFuncionario.getGeneratedKeys();
            int idFuncionario = 0;
            if (rs.next()) {
                idFuncionario = rs.getInt(1);
            }
            rs.close();
            stmtFuncionario.close();

            // Atualiza IDs no objeto funcionario
            funcionario.setId_usuario(idUsuario);
            funcionario.setId_funcionario(idFuncionario);

            return funcionario;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public Funcionario buscarPorCpf(String cpf) {
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            String sqlFuncionario = """
                SELECT
                    u.id_usuario,
                    f.id_funcionario,
                    u.nome,
                    u.cpf,
                    u.senha_hash
                FROM usuario u
                JOIN funcionario f ON f.id_usuario = u.id_usuario
                WHERE (u.cpf) = ? AND tipo_usuario = 'FUNCIONARIO';
            """;

            stmt = conn.prepareStatement(sqlFuncionario);
            stmt.setString(1, cpf);

            rs = stmt.executeQuery();

            if (rs.next()) {
                Funcionario funcionario = new Funcionario();

                // Cliente
                funcionario.setId_usuario(rs.getInt("id_usuario"));
                funcionario.setId_funcionario(rs.getInt("id_funcionario"));
                funcionario.setNome(rs.getString("nome"));
                funcionario.setCpf(rs.getString("cpf"));
                funcionario.setSenha_hash(rs.getString("senha_hash"));

                return funcionario;
            } else {
                return null;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
