import java.util.Date;
import model.persistencia.util.TipoConta;
import model.persistencia.util.Status;

public class Conta {
    private int id_conta;
    private String numero_conta;
    private float saldo;
    private TipoConta tipo_conta;
    private Date data_abertura;
    private Status status;

    public boolean setId_conta(int id_conta) {
        this.id_conta = id_conta;
        return true;
    }

    public int getId_conta() {
        return id_conta;
    }

    public boolean setNumero_conta(String numero_conta) {
        this.numero_conta = numero_conta;
        return true;
    }

    public String getNumero_conta() {
        return numero_conta;
    }

    public boolean setSaldo(float saldo) {
        this.saldo = saldo;
        return true;
    }

    public float getSaldo() {
        return saldo;
    }

    public boolean setTipo_conta(TipoConta tipo_conta) {
        this.tipo_conta = tipo_conta;
        return true;
    }

    public TipoConta getTipo_conta() {
        return tipo_conta;
    }

    public boolean setData_abertura(Date data_abertura) {
        this.data_abertura = data_abertura;
        return true;
    }

    public Date getData_abertura() {
        return data_abertura;
    }

    public boolean setStatus(Status status) {
        this.status = status;
        return true;
    }

    public Status getStatus() {
        return status;
    }
}
