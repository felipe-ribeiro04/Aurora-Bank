package model;


public class TesteConexao {
    public static void main (String[]args) throws ClassNotFoundException{
            Conexao con = new Conexao();
            con.conectar();
    }
}

