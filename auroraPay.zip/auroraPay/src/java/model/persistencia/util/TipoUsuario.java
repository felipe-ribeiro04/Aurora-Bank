
package model.persistencia.util;

import model.persistencia.Cliente;

public enum TipoUsuario {
    FUNCIONARIO,
    CLIENTE;
    
}
