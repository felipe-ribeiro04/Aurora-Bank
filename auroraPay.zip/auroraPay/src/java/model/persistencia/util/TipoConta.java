
package model.persistencia.util;

public enum TipoConta {
    POUPANCA,
    CORRENTE,
    INVESTIMENTO
}