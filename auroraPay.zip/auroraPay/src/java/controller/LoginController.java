
package controller;

public class LoginController {
    //implementar o metodo login
    //tratar os redirecinamentos
}
