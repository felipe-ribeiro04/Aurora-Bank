
package model.persistencia.util;

public enum Status {
    ATIVA,
    ENCERRADA,
    BLOQUEADA
}